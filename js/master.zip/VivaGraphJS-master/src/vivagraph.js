/**
 * @author Andrei Kashcha (aka anvaka) / http://anvaka.blogspot.com
 */
var Viva = Viva || {};

Viva.Graph = Viva.Graph || {};
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Viva;
}
